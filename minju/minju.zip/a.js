const red = document.querySelector('.a_1');
const blue = document.querySelector('.a_2');


document.addEventListener('scroll', function(){
    if (window.scrollY > 100) {
        red.style.backgroundColor = "red"
    } else if (window.scrollY>500 && window.scrollY<1100){
        blue.style.backgroundColor = "blue"
    } else {
        blue.style.backgroundColor = "green"
    }
})
